<?php if ( ! class_exists( 'GPUR_Deactivator' ) ) {
	class GPUR_Deactivator {

		public static function deactivate() {

		}

	}
}	