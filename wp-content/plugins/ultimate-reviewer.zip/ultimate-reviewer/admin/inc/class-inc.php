<?php
 
// Load database update files
require_once( plugin_dir_path( __FILE__ ) . 'database-updates.php' );